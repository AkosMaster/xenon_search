from PIL import Image, ImageDraw, ImageFont
from django.shortcuts import render
from django.conf import settings
import secrets
import string
import time
import os

captchas = {}
chat = {'messages':{},'time':time.time()}

def random_string(length):
    var = ''
    for i in range(length):
        var+=secrets.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits)
    return var

def captcha_check():
    private = random_string(6)
    public = random_string(40)
    captchas.update({public:{'key':private,'time':time.time(),'last_message':1}})
    img_background = (0, 0, 0)
    fnt = ImageFont.truetype('captcha.ttf', 70)
    img = Image.new('RGB', (300, 100), color = img_background)
    d = ImageDraw.Draw(img)
    right = -25+secrets.randbelow(25)
    for i in range(len(private)):
        right+=25+secrets.randbelow(25)
        d.text((right,secrets.randbelow(30)), private[i], font=fnt, fill=(255,255,255))
    img.save('%s/%s.png' % (settings.STATIC_ROOT,public))
    return public

def main(request):
    global chat
    if time.time() - chat['time'] > 86400: #1 day
        chat = {'messages':{},'time':time.time()}
    if request.method == 'GET':
        for f in os.listdir(settings.STATIC_ROOT):
            for captcha in dict(captchas):
                try:
                    os.remove('%s/%s.png' % (settings.STATIC_ROOT,captcha))
                except:
                    pass
        if 'captcha' not in request.GET:
            return render(request,'enterchat.html', {'captcha':captcha_check()})
    else:
        if 'action' in request.POST:
            request.POST['action']
            for captcha_id in captchas:
                if captcha_id == request.POST['captcha'] and time.time() - int(captchas[captcha_id]['time']) <= 900:
                    if request.POST['action'] == 'send':
                        if time.time() - captchas[captcha_id]['last_message'] > 2:
                            chat['messages'].update({random_string(15):'%s: %s' % (request.POST['user'],request.POST['message'])})
                        captchas[captcha_id].update({'last_message':time.time()})
                    return render(request, 'chat.html', {'captcha':request.POST['captcha'], 'chat':chat['messages'], 'user':request.POST['user']})
            captchas.pop(request.POST['captcha'],None)
            return render(request,'enterchat.html', {'class':'error','response':'Your session expired!','captcha':captcha_check()})
        else:
            if not request.POST['captcha'] == captchas[request.POST['captcha_id']]['key']:
                return render(request, 'enterchat.html', {'class':'error','response':'Bad captcha!','captcha':captcha_check()})
            return render(request, 'chat.html', {'captcha':request.POST['captcha_id'], 'chat':chat['messages']})