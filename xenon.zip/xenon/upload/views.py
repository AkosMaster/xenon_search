from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import os
import time
from lxml import etree
from django.conf import settings
import requests
import random
import string
import json
import sys
from PIL import Image, ImageDraw, ImageFont
import secrets

captchas = {}

def captcha_check():
    private = random_string(6)
    public = random_string(40)
    captchas.update({public:private})
    img_background = (0, 0, 0)
    fnt = ImageFont.truetype('captcha.ttf', 70)
    img = Image.new('RGB', (300, 100), color = img_background)
    d = ImageDraw.Draw(img)
    right = -25+secrets.randbelow(25)
    for i in range(len(private)):
        right+=25+secrets.randbelow(25)
        d.text((right,secrets.randbelow(30)), private[i], font=fnt, fill=(255,255,255))
    img.save('%s/%s.png' % (settings.STATIC_ROOT,public))
    return public

def is_open(file_name):
    if os.path.exists(file_name):
        try:
            os.rename(file_name, file_name)
            return False
        except:
            return True
    raise NameError

def fileup(request):
    size = 0
    for f in os.listdir(settings.MEDIA_ROOT):
         size+=os.path.getsize('%s/%s' % (settings.MEDIA_ROOT, f))
    if size>59055800320:
        return render(request, 'uploadfile.html', {'class':'error','response':'Sorry we are currently out of space! Try again later!','captcha':captcha_check()})
    if request.method == 'POST':
        if not request.POST['captcha'] == captchas[request.POST['captcha_id']]:
            return render(request, 'uploadfile.html', {'class':'error','response':'Bad captcha!','captcha':captcha_check()})
        uploaded_file = request.FILES['file']
        if uploaded_file.size <= 52428800:
            while True:
                if not is_open(settings.MEDIA_ROOT + '/files.json'):
                    with FileSystemStorage().open('files.json', 'r') as file:
                        old_data = json.load(file)
                    break
            name = FileSystemStorage().save(uploaded_file.name, uploaded_file)
            name = FileSystemStorage().url(name).replace('/file/','')
            data = {
                name:{
                    'size':uploaded_file.size,
                    'description':'',
                    'upload_time':int(time.time()),
                    'encrypted':False
                }
            }
            if 'description' in request.POST:
                data[name]['description'] = request.POST['description']
            print(data)
            if request.POST['encryption_key']:
                data[name]['encrypted'] = True
                salt = b'\xbe\xb7\xfa\x85\x9eI\x00\xe6\xba\xdc\xb1F-\x8e\xb4w'  
                kdf = PBKDF2HMAC(
                    algorithm = hashes.SHA256(),
                    length = 32,
                    salt = salt,
                    iterations = 100000,
                    backend = default_backend()
                )
                key = base64.urlsafe_b64encode(kdf.derive(request.POST['encryption_key'].encode()))
                fernet = Fernet(key)
                with FileSystemStorage().open(name, 'rb') as file:
                    encdata = file.read()
                with FileSystemStorage().open(name, 'wb') as file:
                    file.write(fernet.encrypt(encdata))
               
            old_data['files'].update(data)
            while True:
                if not is_open(settings.MEDIA_ROOT + '/files.json'):
                    with FileSystemStorage().open('files.json', 'w') as file:
                        json.dump(old_data, file)
                    break
            return render(request, 'uploadfile.html', {'class':'success','response':f'{name} uploaded successfully!','captcha':captcha_check()})
        else:
            return render(request, 'uploadfile.html', {'class':'error','response':'This file is too big!','captcha':captcha_check()})
    else:
        for f in os.listdir(settings.STATIC_ROOT):
            for captcha in dict(captchas):
                try:
                    os.remove('%s/%s.png' % (settings.STATIC_ROOT,captcha))
                except:
                    pass
        return render(request, 'uploadfile.html', {'captcha':captcha_check()})
    return render(request, 'uploadfile.html')

def link_check(data, link):
    for url in data['urls']:
        if link[link.index('://'):link.index('.')] in url:
            return False
    return True

def random_string(length):
    var = ''
    for i in range(length):
        var+=secrets.choice(string.ascii_lowercase + string.ascii_uppercase + string.digits)
    return var  

def linkup(request):
	#PROXY START#
    tor = {
        'http': 'socks5h://127.0.0.1:9050',
        'https': 'socks5h://127.0.0.1:9050'
    }

    i2p = {
        'http': 'http://127.0.0.1:4444',
        'https': 'https://127.0.0.1:4444'
    }
    #PROXY END#

    if request.method == 'POST':
        link = request.POST['url'].lower().strip()
        if '.onion' in link or '.i2p' in link:
            if 'http' not in link:
                link = 'http://' + link
            while True:
                if not is_open(settings.MEDIA_ROOT + '/urls.json'):
                    with FileSystemStorage().open('urls.json', 'r') as file:
                        old_data = json.load(file)
                    break
            if not link_check(data=old_data,link=link):
                return render(request, 'uploadlink.html', {'class':'error','response':'This URL is already uploaded!'}) 
            try:
                RESPONSE_TIME = time.time()
                if '.onion' in link:
                    link = requests.get(url=link[:link.index('.onion')+6], proxies=tor, timeout=15, headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; rv:68.0) Gecko/20100101 Firefox/68.0'})
                else:
                    link = requests.get(url=link[:link.index('.i2p')+4], proxies=i2p, timeout=20, headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; rv:68.0) Gecko/20100101 Firefox/68.0'})
                link.close()
                RESPONSE_TIME = '%.2f' % (time.time() - RESPONSE_TIME)
            except requests.exceptions.Timeout:
                return render(request, 'uploadlink.html', {'class':'error','response':'Timed out!'})
            except requests.exceptions.RequestException:
                return render(request, 'uploadlink.html', {'class':'error','response':'Invalid URL or site is not online!'})
            if '.onion' not in link.url and '.i2p' not in link.url:
                return render(request, 'uploadlink.html', {'class':'error','response':'Redirected to clearnet site!'})
            try:
                link.raise_for_status()
            except requests.exceptions.HTTPError:
                return render(request, 'uploadlink.html', {'class':'error','response':'%s returned the status code of %s!' % (link.url, link.status_code)}) 
            if not link_check(data=old_data,link=link.url):
                return render(request, 'uploadlink.html', {'class':'error','response':'This URL is already uploaded!'})
            root = etree.HTML(link.content)
            if 'CP ' in link.text or ' CP' in link.text or 'child' in link.text.lower() or 'pedo' in link.text.lower():
                if 'porn' in link.text.lower():
                    return render(request, 'uploadlink.html', {'class':'error','response':'Forbidden content.'})
            data = {
                link.url:{
                    'title':'',
                    'description':'',
                    'keywords':'',
                    'length':len(link.content),
                    'size':sys.getsizeof(link.content),
                    'upload_time':int(time.time()),
                    'response_time':float(RESPONSE_TIME),
                    'content_type':link.headers["content-type"]
                }
            }

            if root.findtext('.//title') !=None:
                data[link.url]['title'] = root.findtext('.//title')
                if (len(data[link.url]['title']) >= 100):
                    data[link.url]['title'] = data[link.url]['title'][0:100]
                    
            if '.onion' in link.url:
                data[link.url]['hidden_service'] = 'Tor'
            else:
                data[link.url]['hidden_service'] = 'I2P'
            if 'keywords' in request.POST:
                data[link.url]['keywords'] = request.POST['keywords']
            description = ''
            for p in root.iter('p'):
                if p.text!=None:
                    description+='%s ' % (p.text)
                if len(description)>=300:
                    data[link.url]['description'] = description[0:300].strip()
                    description = ''
                    break
            if description!='':
                data[link.url]['description'] = description.strip()
            data.update(old_data['urls'])
            while True:
                if not is_open(settings.MEDIA_ROOT + '/urls.json'):
                    with FileSystemStorage().open('urls.json', 'w') as file:
                        json.dump({'urls':data},file, indent=4)
                    break
            return render(request, 'uploadlink.html', {'class':'success','response':'Uploaded %s successfully!' % (link.url)})
        else:
            return render(request, 'uploadlink.html', {'class':'error','response':'Invalid URL!'})
    return render(request,'uploadlink.html')
