from django.urls import path
from . import views

urlpatterns = [
    path('file/', views.fileup, name='upload-file'),
    path('url/', views.linkup, name='upload-link')
]