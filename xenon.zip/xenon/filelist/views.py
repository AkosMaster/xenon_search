from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.conf import settings
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from django.conf import settings
from django.http import HttpResponse
import base64
import json
import os

def main(request):
    with FileSystemStorage().open('files.json', 'r') as file:
        data = json.load(file)
    file_list = dict(data['files'])
    for file in file_list:
         if file not in os.listdir(settings.MEDIA_ROOT):
            data['files'].pop(file, None)
    with FileSystemStorage().open('files.json', 'w') as file:
        json.dump(data, file)
    if request.method == "POST":
        if 'size' in request.POST:
            good_list = []
            bad_list = []
            for element in data['files']:
                good_file = True
                if request.POST['file']:
                    if not request.POST['file'].lower().strip() in element.lower():
                        good_file = False
                if request.POST['upload_time']:
                    try:
                        if not int(request.POST['upload_time']) <= data['files'][element]['upload_time']:
                            good_file = False
                    except:
                        good_file = False
                if request.POST['size']:
                    try:
                        if not int(request.POST['size']) >= data['files'][element]['size']:
                            good_file = False
                    except:
                        good_file = False
                if request.POST['description']:
                    if not request.POST['description'].lower().strip() in data['files'][element]['description'].lower():
                        good_file = False
                if request.POST['encrypted']:
                    if request.POST['encrypted']=='true':
                       if data['files'][element]['encrypted'] == False:
                           good_file = False
                    elif request.POST['encrypted']=='false':
                        if data['files'][element]['encrypted'] == True:
                           good_file = False
                if good_file:
                    good_list.append(element)
                else:
                    bad_list.append(element)
            for element in bad_list:
                data['files'].pop(element, None)
            return render(request, 'filelist.html', data)

        file_path = os.path.join(settings.MEDIA_ROOT, request.POST['file'])
        if os.path.exists(file_path):
            if 'key' in request.POST:
                salt = b'\xbe\xb7\xfa\x85\x9eI\x00\xe6\xba\xdc\xb1F-\x8e\xb4w'  
                kdf = PBKDF2HMAC(
                    algorithm = hashes.SHA256(),
                    length = 32,
                    salt = salt,
                    iterations = 100000,
                    backend = default_backend()
                )
                key = base64.urlsafe_b64encode(kdf.derive(request.POST['key'].encode()))
                fernet = Fernet(key)
                with open(file_path, 'rb') as file:
                    try:
                        response = HttpResponse(fernet.decrypt(file.read()), content_type="application/vnd.ms-excel")
                    except:
                        return render(request,'filelist.html', data)
                    response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
                    return(response)
            else:
                with open(file_path, 'rb') as file:
                    response = HttpResponse(file.read(), content_type="application/vnd.ms-excel")
                    response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
                    return(response) 
    return render(request,'filelist.html', data)
