from django.apps import AppConfig


class FilelistConfig(AppConfig):
    name = 'filelist'
