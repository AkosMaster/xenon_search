from django import template
import datetime

register = template.Library()

def convert(value):
	timestamp = datetime.datetime.fromtimestamp(value)
	return timestamp.strftime('%Y-%m-%d')
register.filter('convert', convert)