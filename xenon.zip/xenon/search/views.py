from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
import json
from django.http import JsonResponse
import math
import os
from django.conf import settings
import secrets

def is_open(file_name):
    if os.path.exists(file_name):
        try:
            os.rename(file_name, file_name)
            return False
        except:
            return True
    raise NameError

def main(request):
    placeholder = []
    while True:
        if not is_open('placeholder.txt'):
            with open('placeholder.txt', 'r') as f:
                for line in f:
                   placeholder.append(line.strip())
            break
    placeholder = secrets.choice(placeholder)
    if 'search' in request.GET:
        search = list(str(request.GET['search']).lower().strip().split(' '))
        search = list(filter(None, search))
        while True:
            if not is_open(settings.MEDIA_ROOT + '/urls.json'):
                with FileSystemStorage().open('urls.json', 'r') as file:
                    data = json.load(file)
                break
        if 'page' not in request.GET:
            page = 1
        elif request.GET['page_action']=='next':
            page = int(request.GET['page']) + 1
        elif request.GET['page_action']=='previous':
            page = int(request.GET['page']) - 1
        data.update({'page':page})
        for url in dict(data['urls']):
            good_url = False
            if 'hidden_service' in request.GET:
                if request.GET['hidden_service'] == 'tor':
                    if data['urls'][url]['hidden_service'] == 'I2P':
                        data['urls'].pop(url, None)
                elif request.GET['hidden_service'] == 'i2p':
                    if data['urls'][url]['hidden_service'] == 'Tor':
                        data['urls'].pop(url, None)
        if not request.GET['search'].strip()=='':           
            for url in dict(data['urls']):
                good_url = False
                data['urls'][url]['score'] = 1
                for keyword in search:
                    added_score = 1
                    if keyword in url:
                        good_url = True
                    if type(data['urls'][url]['title']) is str:
                        if keyword in data['urls'][url]['title'].lower().strip():
                            good_url = True
                            added_score += data['urls'][url]['title'].lower().strip().count(keyword)
                    else:
                        data['urls'][url]['title'] = ""
                    if keyword in data['urls'][url]['description'].lower().strip():
                        good_url = True
                        added_score += data['urls'][url]['description'].lower().strip().count(keyword)
                    if keyword in data['urls'][url]['keywords'].lower().strip():
                        good_url = True
                        added_score += data['urls'][url]['keywords'].lower().strip().count(keyword)
                    data['urls'][url]['score'] *= added_score
                if not good_url:
                    data['urls'].pop(url, None)

            data_array = []
            for x in data["urls"]:
                data_array.append([x, data["urls"][x]])

            data_array = sorted(data_array, key = lambda x: int(x[1]["score"]), reverse=True)
        
            new_data = {"urls":{}}
            for x in data_array:
                new_data["urls"][x[0]] = x[1]

            data = new_data      
            
        if page <= 0 or page*10>int(math.ceil(len(data['urls'].keys()) / 10.0)) * 10:
            return render(request,'search.html', {'placeholder':placeholder})
        number = len(data['urls'].keys())-page*10
        if number < 0:
            number = 0
        formatted_data = {'urls':{},'number':number}
        for index,url in enumerate(data['urls']):
            if index>=(page*10)-10 and index<=(page*10)-1:
                formatted_data['urls'].update({url:data['urls'][url]})
            elif index>page*10-1:
                break
        formatted_data.update({'search':request.GET['search'],'page':page, 'hidden_service':request.GET['hidden_service'].strip()})
        if 'json' in request.GET:
            if request.GET['json']=='on':
                return JsonResponse(data['urls'])
        return render(request,'results.html', formatted_data)
    return render(request,'search.html', {'placeholder':placeholder})