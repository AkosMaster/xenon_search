from django import template
import datetime

register = template.Library()

def convert(value):
	timestamp = datetime.datetime.utcfromtimestamp(value)
	return timestamp.strftime('%Y-%m-%d %H:%M:%S')
register.filter('convert', convert)