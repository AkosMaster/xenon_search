-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 09, 2019 at 04:22 PM
-- Server version: 8.0.13-4
-- PHP Version: 7.2.24-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bgCXtkh8BL`
--

-- --------------------------------------------------------

--
-- Table structure for table `APP_UPDATES`
--

CREATE TABLE `APP_UPDATES` (
  `FILE_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `USERNAME` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `PASSWORD` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `LINK` text COLLATE utf8_unicode_ci NOT NULL,
  `VERSION` varchar(5) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `APP_UPDATES`
--

INSERT INTO `APP_UPDATES` (`FILE_NAME`, `USERNAME`, `PASSWORD`, `LINK`, `VERSION`) VALUES
('libraryapp-setup.exe', 'judalion7772@gmail.com', 'DansoftwareOwner777', 'https://mega.nz/#!pcdSzY5T!60hEQZmIEZ5ntDRK5qyfSLam6yKNxXV6_HocZZtoncg', '0.6.1');

-- --------------------------------------------------------

--
-- Table structure for table `Authors`
--

CREATE TABLE `Authors` (
  `AuthorID` smallint(6) NOT NULL,
  `AuthorFirstName` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `AuthorLastName` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `InvertName` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Authors`
--

INSERT INTO `Authors` (`AuthorID`, `AuthorFirstName`, `AuthorLastName`, `InvertName`) VALUES
(4, 'King', 'James', 1),
(12, 'Jules', 'Verne', 1),
(14, 'Mark', 'Twain', 1),
(15, 'Josy', 'Doyon', 1),
(31, 'LajosKácska', 'Almáska', 0),
(37, 'Mártonság', 'Biciklis', 0),
(39, 'Köcsög', 'FItymálékos', 0),
(43, 'Mártonka', 'Biciklis', 0),
(44, 'István', 'Tótfalusi', 0),
(45, 'Béla', 'Buba', 0),
(46, 'Béla', 'Bligi-Blogi', 0),
(47, 'Kibor', 'Szanyi', 0),
(48, 'Karcsi', 'Manyiel', 0),
(49, 'Tímea', 'Horváth', 0),
(50, 'ÍróKeresztnév', 'Íróvezetékév', 0),
(53, 'maniel', 'laliel', 0),
(54, 'Mazsnyi', 'Szsnyi', 0),
(55, 'Maniy', 'Sanyiel', 0),
(56, 'Mazsnyi', 'Manyiel', 0),
(57, 'xcyxc', 'yxcyc', 0),
(58, 'Mór', 'Jókai', 0),
(60, 'Carl', 'May', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Books`
--

CREATE TABLE `Books` (
  `BookID` smallint(6) NOT NULL,
  `BookName` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `Notes` varchar(80) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PublishedIn` smallint(4) DEFAULT NULL,
  `PublisherID` smallint(6) DEFAULT NULL,
  `AuthorID` smallint(6) NOT NULL,
  `GenreID` smallint(6) DEFAULT NULL,
  `ThemeID` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Books`
--

INSERT INTO `Books` (`BookID`, `BookName`, `Notes`, `PublishedIn`, `PublisherID`, `AuthorID`, `GenreID`, `ThemeID`) VALUES
(20, 'Basások.', NULL, 1999, 3, 4, 3, 3),
(22, 'Szaturnusz kutatás sikertelenül ', 'sanyi', 1555, 12, 31, 1, 2),
(25, 'Kétévi vakáció', NULL, NULL, NULL, 12, NULL, NULL),
(26, 'Tom Sawyer', 'Mark Twain egyik leghíresebb regénye.', 1990, 8, 14, 1, 8),
(27, 'Jehova Tanúja Voltam', 'magyar nyelven', 1998, 9, 15, 7, 23),
(39, 'Manyi a holdon', NULL, 1222, 10, 43, 18, 15),
(41, 'Kénkő', NULL, NULL, NULL, 39, NULL, NULL),
(45, 'Laló', NULL, NULL, NULL, 37, NULL, NULL),
(46, 'VADEMECUM', NULL, 1983, 16, 44, 20, 17),
(47, 'vmi más', NULL, NULL, NULL, 44, NULL, NULL),
(48, 'Grant kapotány gyermekei', NULL, NULL, NULL, 12, 1, NULL),
(53, 'sadsa', NULL, NULL, NULL, 37, NULL, NULL),
(57, 'Lalika a marsom', NULL, NULL, NULL, 45, NULL, NULL),
(59, 'Babuska Dándurucska a Cloud fejlesztések tengerébe', 'Szélbeszórt szókapcsok sorozata', 2222, 17, 46, 21, 19),
(60, 'Maniel', NULL, NULL, NULL, 47, NULL, NULL),
(61, 'Címecske', 'jegyzetecskeeeee.', 1222, 18, 48, 22, 20),
(62, 'Mázalékok mártaléka', 'jegyzetek.', 1233, 18, 49, 22, 20),
(63, 'Konyvcím', NULL, NULL, NULL, 50, NULL, NULL),
(64, 'Nemo Kapitány', 'Jegyzets.', 1999, 6, 12, 1, 21),
(65, 'A tizenöt éves kapitány', NULL, 1989, 6, 12, 1, 22),
(66, '80 nap alatt a föld körül', 'Jajaja.', 1889, 6, 12, 1, 6),
(67, 'Rejtelmes Sziget', NULL, NULL, NULL, 12, 1, NULL),
(68, 'Utazás a föld középpontja felé', NULL, NULL, NULL, 12, 1, NULL),
(71, 'Sanyi', NULL, NULL, NULL, 53, NULL, NULL),
(72, 'Batyi', NULL, NULL, NULL, 53, NULL, NULL),
(73, 'Lailekallleadfdsf777', NULL, NULL, NULL, 54, 24, NULL),
(74, 'Kafirke', NULL, NULL, NULL, 55, 24, NULL),
(75, 'Valami mős', NULL, NULL, NULL, 56, NULL, NULL),
(76, 'xcx', NULL, NULL, NULL, 57, NULL, NULL),
(77, 'Aranyember', NULL, NULL, NULL, 58, 1, NULL),
(79, 'Winettouu', NULL, NULL, NULL, 60, 25, 25);

-- --------------------------------------------------------

--
-- Table structure for table `Genres`
--

CREATE TABLE `Genres` (
  `GenreID` smallint(6) NOT NULL,
  `GenreName` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Genres`
--

INSERT INTO `Genres` (`GenreID`, `GenreName`) VALUES
(7, 'Dokumentumregény'),
(18, 'Francság'),
(25, 'kalandregény'),
(22, 'Mufaj'),
(21, 'Ötvözetfúró elemzéspoetika'),
(1, 'Regény'),
(24, 'SDSD'),
(20, 'Szótár'),
(3, 'Történelmi könyv');

-- --------------------------------------------------------

--
-- Table structure for table `Publishers`
--

CREATE TABLE `Publishers` (
  `PublisherID` smallint(6) NOT NULL,
  `PublisherName` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Publishers`
--

INSERT INTO `Publishers` (`PublisherID`, `PublisherName`) VALUES
(9, 'Agapé'),
(3, 'Bálint kiadó'),
(17, 'Brogger-drákó '),
(8, 'Editorg kiadó'),
(18, 'Kiadü'),
(10, 'ManyiKiadó'),
(16, 'Móra Ferenc Kia'),
(6, 'Móra kiadó'),
(12, 'Nasa Kiadó');

-- --------------------------------------------------------

--
-- Table structure for table `Themes`
--

CREATE TABLE `Themes` (
  `ThemeID` smallint(6) NOT NULL,
  `ThemeName` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Themes`
--

INSERT INTO `Themes` (`ThemeID`, `ThemeName`) VALUES
(15, 'Babság'),
(23, 'Életút történet. 10 év tapasztalata'),
(21, 'Kalandok az óceánban'),
(19, 'Meghajtásos szóözönbeszúró tehéntejemelő gépezet'),
(8, 'Missisipi gyerekek élete'),
(22, 'Rabszolgakereskedelem és hajózás'),
(2, 'Sanyi egy köcsög'),
(17, 'Szokatlan szavak'),
(20, 'Tema'),
(3, 'Török elnyomás'),
(6, 'Utazás'),
(25, 'wild west');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Authors`
--
ALTER TABLE `Authors`
  ADD PRIMARY KEY (`AuthorID`);

--
-- Indexes for table `Books`
--
ALTER TABLE `Books`
  ADD PRIMARY KEY (`BookID`),
  ADD KEY `PublisherID` (`PublisherID`),
  ADD KEY `AuthorID` (`AuthorID`),
  ADD KEY `GenreID` (`GenreID`),
  ADD KEY `ThemeID` (`ThemeID`);

--
-- Indexes for table `Genres`
--
ALTER TABLE `Genres`
  ADD PRIMARY KEY (`GenreID`),
  ADD UNIQUE KEY `GenreName` (`GenreName`);

--
-- Indexes for table `Publishers`
--
ALTER TABLE `Publishers`
  ADD PRIMARY KEY (`PublisherID`),
  ADD UNIQUE KEY `PublisherName` (`PublisherName`);

--
-- Indexes for table `Themes`
--
ALTER TABLE `Themes`
  ADD PRIMARY KEY (`ThemeID`),
  ADD UNIQUE KEY `ThemeName` (`ThemeName`),
  ADD UNIQUE KEY `ThemeName_2` (`ThemeName`),
  ADD UNIQUE KEY `ThemeName_3` (`ThemeName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Authors`
--
ALTER TABLE `Authors`
  MODIFY `AuthorID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `Books`
--
ALTER TABLE `Books`
  MODIFY `BookID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `Genres`
--
ALTER TABLE `Genres`
  MODIFY `GenreID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `Publishers`
--
ALTER TABLE `Publishers`
  MODIFY `PublisherID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `Themes`
--
ALTER TABLE `Themes`
  MODIFY `ThemeID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Books`
--
ALTER TABLE `Books`
  ADD CONSTRAINT `Books_ibfk_1` FOREIGN KEY (`PublisherID`) REFERENCES `Publishers` (`publisherid`),
  ADD CONSTRAINT `Books_ibfk_2` FOREIGN KEY (`AuthorID`) REFERENCES `Authors` (`authorid`),
  ADD CONSTRAINT `Books_ibfk_3` FOREIGN KEY (`GenreID`) REFERENCES `Genres` (`genreid`),
  ADD CONSTRAINT `Books_ibfk_4` FOREIGN KEY (`ThemeID`) REFERENCES `Themes` (`themeid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
