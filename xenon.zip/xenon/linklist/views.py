from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from django.http import JsonResponse
import json
from django.conf import settings
from django.http import HttpResponse, Http404
import os

def main(request):
    with FileSystemStorage().open('links.json', 'r') as file:
        data = json.load(file)
    if request.method == 'POST':
        good_list = []
        bad_list = []
        for element in data['links']:
            good_site = True
            if request.POST['title']:
                if not request.POST['title'].lower().strip() in data['links'][element]['title'].lower():
                    good_site = False
            if request.POST['description']:
                if not request.POST['description'].lower().strip() in data['links'][element]['description'].lower():
                    good_site = False
            if request.POST['upload_time']:
                try:
                    if not int(request.POST['upload_time']) <= data['links'][element]['upload_time']:
                        good_site = False
                except:
                    good_site = False
            if request.POST['response_time']:
                try:
                    if not int(request.POST['response_time']) >= data['links'][element]['response_time']:
                        good_site = False
                except:
                    good_site = False
            if request.POST['hidden_service']:
                if not request.POST['hidden_service'] in data['links'][element]['hidden_service'] and request.POST['hidden_service']!='all':
                    good_site = False
            if request.POST['category']:
                if request.POST['category']!=data['links'][element]['category'] and request.POST['category']!='all':
                    good_site = False
            if good_site:
                good_list.append(element)
            else:
                bad_list.append(element)
        for element in bad_list:
            data['links'].pop(element, None)
    return render(request, 'linklist.html', data)

def jsonlist(request):
    with FileSystemStorage().open('links.json', 'r') as file:
            data = json.load(file)
    return JsonResponse(data)