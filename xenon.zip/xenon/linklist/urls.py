from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='linklist-main'),
    path('json/', views.jsonlist, name='linklist-jsonlist')
]