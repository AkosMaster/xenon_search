from django.apps import AppConfig


class LinklistConfig(AppConfig):
    name = 'linklist'
