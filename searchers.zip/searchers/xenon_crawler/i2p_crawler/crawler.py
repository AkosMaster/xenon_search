#usr/bin/env python3
import sys
import time
import random
import requests
from lxml import etree

import datetime

I2P = {
        'http': 'http://127.0.0.1:4444/',
        'https': 'https://127.0.0.1:4444/'
}

TOR = {
    'http':'socks5h://localhost:9050',
    'https':'socks5h://localhost:9050'
}

SESSION = requests.session()
url_list = []
url_list_tried = []
url_list_base = []

previous_tried = []

def load():
    global url_list
    global url_list_tried
    global url_list_base
    url_list = []
    url_list_tried = []
    url_list_base = []
    with open('tried.txt', 'r') as file:
        for line in file:
            url_list_tried.append(line.strip())

    with open('loaded.txt', 'r') as file:
        for line in file:
            url_list.append(line.strip())

    with open('base.txt', 'r') as file:
        for line in file:
            url_list_base.append(line.strip())

def save():
    # save new loaded and tried
    with open('loaded.txt', 'w') as file:
        for item in url_list:
            try:
                file.write((item + "\n"))
            except:
                pass

    with open('tried.txt', 'w') as file:
        for item in url_list_tried:
            try:
                file.write((item + "\n"))
            except:
                pass

    with open('base.txt', 'w') as file:
        for item in url_list_base:
            try:
                file.write((item + "\n"))
            except:
                pass

while True:

    previous_tried = url_list_tried
    load()

    print("\n")
    
    print ("Collected urls: " + str(len(url_list)))
    if len(url_list) == 0:
        print("[ERROR] Out of urls.")
        break

    url_current = ""

    if len(url_list_base) > 0:
        url_current = random.choice(url_list_base)
        url_list_base.remove(url_current)
        if url_current in url_list:
            url_list.remove(url_current)
        print("(BASE URL)")
    else:
        url_current = random.choice(url_list)
        url_list.remove(url_current)

    if url_current == "":
        continue

    print(url_current)
    
    save()

    # FIX HTTP PREFIX AND CHECK FOR NONETYPE
    if url_current == None:
        continue
    if url_current in url_list_tried:
        print ("[ALREADY TRIED]")
        continue

    url_list_tried.append(url_current)
    
    if 'http' not in url_current:
        url_current = 'http://%s' % (url_current)

    base_url = url_current.split("://")[0] + "://" + url_current.split("://")[1].split("/")[0]

    print("| i2p: " + base_url)

    try:
        response = SESSION.get(url=url_current, proxies=I2P, timeout=20, headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; rv:68.0) Gecko/20100101 Firefox/68.0'})
        html = response.content
        if not response.status_code == 200:
            print ("[STATUS CODE " + str(response.status_code) + "]")
            continue
    except KeyboardInterrupt:
        sys.exit()
    except:
        print ("[NOT RESPONDING]")
        continue

    root = etree.HTML(html, parser=etree.HTMLParser())

    new_counter = 0
    for tag in root.iterfind(".//a"):
        if not tag == None and not tag.get('href') == None and len(tag.get("href")) > 0:
            if not '.i2p' in tag.get('href') and 'http://' not in tag.get('href') and 'https://' not in tag.get('href'):
                if (tag.get("href")[0] == '.'):
                    link = url_current + tag.get("href")
                if (tag.get("href")[0] == '/'):
                    link = base_url + tag.get("href")
                else:
                    link = base_url + "/" + tag.get("href")
            else:
                link = tag.get("href")
            
            if link[-1] == '/':
                link = link [0:-1]
                
            if (link not in url_list) and (link not in url_list_tried) and ".i2p" in link:
                new_counter += 1
                url_list.append(link)
                try:
                    base_link = link.split("://")[0] + "://" + link.split("://")[1].split("/")[0]
                    if not base_link in url_list_base and not base_link in url_list_tried:
                        url_list_base.append(base_link)
                except:
                    pass

    if new_counter > 0:
        print("| +" + str(new_counter) + " links")

    save()

    if base_url in previous_tried:
        print ("[SKIPPED]")
        continue

    SESSION.get('http://xenon3oeazebb7aa.onion/upload/url/', proxies=TOR, headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; rv:68.0) Gecko/20100101 Firefox/68.0'})
    csrftoken = SESSION.cookies['csrftoken']
    login_data = dict(url=url_current, csrfmiddlewaretoken=csrftoken, next='/')
    r = SESSION.post(url='http://xenon3oeazebb7aa.onion/upload/url/', data=login_data, proxies=TOR, headers=dict(Referer='http://xenon3oeazebb7aa.onion/upload/url/'))

    del SESSION.cookies['csrftoken']

    if ("Forbidden" in str(r.content)):
        print ("[FILTERED]")
    elif ("already uploaded" in str(r.content)):
        print ("[DUPLICATE]")
    elif ("successfully" in str(r.content)):
        print ("[APPROVED]")
    else:
        print ("[REJECTED]")

input()
                    

    
